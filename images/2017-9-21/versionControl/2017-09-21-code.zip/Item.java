package com.talkweb.nets.netsTestLib.data.model.basicitem;

import java.util.ArrayList;
import java.util.List;

import com.talkweb.nets.netsTestLib.common.consts.Constants;
import com.talkweb.nets.netsTestLib.data.model.BaseEntity;
import com.talkweb.nets.netsTestLib.data.po.PaperStructurePO;

/**
 * 试题信息
 * 
 * @author wangbo
 *
 */
public class Item extends BaseEntity {
	// date formats
	public static final String FORMAT_CREATE_TIME = DATE_TIME_FORMAT;
	
	private String taskId; // 任务编号
	
	private String id; // 试题编号
	private String subjectId; // 科目编号
	private String itemTypeId; // 题型(单选题、多选题、判断题、不定项选择题、简答题、计算分析题、综合题)
	private Double score; // 分数(试题只有关联到某张试卷时才会有分数, 故新增试题界面指定的试题分数要入到试卷结构与试题关系表中,
							// 修改时要从此表取数据)
	private String itemContent; // 题干内容（itemContent仅用于前台展示,
								// 制卷导出生成静态文件或预览时需要将<input>转换成##）
	private String description; // 说明
	private String keyWord; // 关键字
	private String itemVersion; // 试题版本
	private String difficult; // 预估难度系数0.1-0.9
	private String parentId; // 父试题ID
	//初级1，中级2；科目A、B、C分别代表三个科目；
	private String itemCode; // 试题代码 2C22000000747474，第一个2是考试级别，C是科目，22是章，第一个00是节，第二个00是目，第三个00是知识点
	private Integer itemLevel; // 试题级别0 顶级小题; 1为复合题下的小题; 2 继续延伸
	private Integer answerCount; // 答案总个数
	private String auditor; // 审核人
	private Integer auditStatus; //在用的审核状态（0-未审核,  1-审核退回, 2-审核通过）//暂未启用 审核状态（0-未审核, 试题试审: 1-试审退回, 2-试审待修改, 3-试审通过; 试题预审: 4-预审退回,5-预审待修改,6-预审通过; 试题初审: 7-初审退回, 8-初审待修改, 9-初审通过; 试题复审: 10-复审退回, 11-复审待修改, 12-复审通过）
	private java.sql.Timestamp auditTime; // 审核时间
	private String creater; // 创建人
	private java.sql.Timestamp createTime; // 创建时间
	private String updater; // 修改人
	private java.sql.Timestamp updateTime; // 修改时间
	private Integer lockStatus; // 锁定状态: (1 未锁定; 2 已锁定)
	private String locker; // 锁定人
	private java.sql.Timestamp lockTime; // 锁定时间
	private Integer sort; // 排序 单个试题无所谓排序,挂在复合题下的小题有排序
	private Integer showModel; // 题目展示模式(特定的试题展示模式对应了特定的展示模板)
	private Integer isFinished;//0-未完成编辑, 1-完成编辑
	private String syllabusBasis; //大纲依据61/61,62,63
    private String teachingMaterialBasis; //教材依据 61/61,62,63
    private String abilityLevel; //能力层次 1-熟悉, 2-掌握, 3-了解
    private String actualDifficult; //实测难度系数0.1-0.9（实际考试后反馈回来）
    private String checkStatus; //校核状态 1-通过, 2-未通过
    private String discrimination;//区分度：数字（实际考试后反馈回来）
    private String userNumber; //人数（实际考试后反馈回来）
    private String paperName; //卷名（实际考试后反馈回来）
    private String module; //模块 不定项选择特有
    private String knowledgeId; //知识点（非复合题是展示自身知识点，复合题的父题展示所有小题的知识点集合, 另附加知识点展示父题自身的知识点）
	private String knowledgeStr;
    private String extNo; //外部试题编号
    private String cognitiveGoal; //认知目标: 1-知识／2-领会／3-运用／4-分析／5-综合／6-评价
    private String itemSource; //试题来源
    private String propositionCollege; //命题院校
    private String analysis; //解析
    private String answer; //答案
    private Integer isComposite=0; //是否复合题: 0-不是复合题, 1-是复合题
    private String delFlag; //逻辑删除标志：0表示可用 1表示删除
	
	private String processedItemContent; // 处理过的itemContent(填空题拖拽题中将inputbox替换成分隔符##后存放到此处)
	// 题目扩展属性集合
	private List<ItemAttribute> attributeList = new ArrayList<ItemAttribute>();
	private ItemType itemType; // 题型信息
	private List<Item> childItemList = new ArrayList<Item>(); // 子题列表
	private PaperItemRelation paperItemRelation = new PaperItemRelation();
	private PaperStructurePO paperStructure = new PaperStructurePO();
	// columns END

	private java.sql.Timestamp auditTimeBegin;
	private java.sql.Timestamp auditTimeEnd;
	private java.sql.Timestamp createTimeBegin;
	private java.sql.Timestamp createTimeEnd;
	private java.sql.Timestamp updateTimeBegin;
	private java.sql.Timestamp updateTimeEnd;
	private java.sql.Timestamp lockTimeBegin;
	private java.sql.Timestamp lockTimeEnd;

	private String itemTypeName;
	private String structId;
	private Item parenItem; // 父题,在试题静态化到freemarker模板时才会绑定父题
	private Integer dth;// 大题号(取试卷结构排序号)
	private Integer xth;// 小题号
	private String xtdm; // 小题代码
	private String fxtdm; // 父小题代码
	private String xtmc; // 小题名称(1-3、1.、2.、3.)
	private Integer zjxh; // 章节序号
	private String xtlx; // 小题类型（用于考试系统复合题：COMPOSITE、单选题：SINGLE、图片单选题：SINGLEIMAGE、填空题：TEXT、文字拖拽题：DRAG、图片拖拽题：DRAGIMAGE、写作题：WRITE、多选题：MULTIPLE、判断题：JUDGMENT、不定项选择：SMULTIPLE、下拉选择：COMBOBOX）
	private String itemGroupTitleSection; // 试题分组标题节
	private String itemGroupTitleGuide; // 试题分组标题引导说明
	private String startGuideAudio; // 试题开始引导音频
	private String startGuideAudioName;
	private String endGuideAudio; // 试题结束引导音频
	private String endGuideAudioName;

	private String extJson;// 附加属性json串
	private String activityId; //题目修改记录中记录活动ID
    

	public String getExtJson() {
		return extJson;
	}

	public void setExtJson(String extJson) {
		this.extJson = extJson;
	}

	public String getActivityId() {
        return activityId;
    }

    public void setActivityId(String activityId) {
        this.activityId = activityId;
    }

    public String getStructId() {
		return structId;
	}

	public void setStructId(String structId) {
		this.structId = structId;
	}

	public String getItemTypeName() {
		return itemTypeName;
	}

	public void setItemTypeName(String itemTypeName) {
		this.itemTypeName = itemTypeName;
	}

	public Item() {
	}

	public Item(String id) {
		this.id = id;
	}

	public String getTaskId() {
		return taskId;
	}

	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getSubjectId() {
		return subjectId;
	}

	public void setSubjectId(String subjectId) {
		this.subjectId = subjectId;
	}

	public String getItemTypeId() {
		return itemTypeId;
	}

	public void setItemTypeId(String itemTypeId) {
		this.itemTypeId = itemTypeId;
	}

	public Double getScore() {
		return score;
	}

	public void setScore(Double score) {
		this.score = score;
	}

	public String getItemContent() {
		return itemContent;
	}

	public void setItemContent(String itemContent) {
		this.itemContent = itemContent;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getKeyWord() {
		return keyWord;
	}

	public void setKeyWord(String keyWord) {
		this.keyWord = keyWord;
	}

	public String getItemVersion() {
		return itemVersion;
	}

	public void setItemVersion(String itemVersion) {
		this.itemVersion = itemVersion;
	}

	public String getDifficult() {
		return difficult;
	}

	public void setDifficult(String difficult) {
		this.difficult = difficult;
	}

	public String getParentId() {
		return parentId;
	}

	public void setParentId(String parentId) {
		this.parentId = parentId;
	}

	public String getItemCode() {
		return itemCode;
	}

	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}

	public Integer getItemLevel() {
		return itemLevel;
	}

	public void setItemLevel(Integer itemLevel) {
		this.itemLevel = itemLevel;
	}

	public Integer getAnswerCount() {
		return answerCount;
	}

	public void setAnswerCount(Integer answerCount) {
		this.answerCount = answerCount;
	}

	public Integer getAuditStatus() {
		return auditStatus;
	}

	public void setAuditStatus(Integer auditStatus) {
		this.auditStatus = auditStatus;
	}

	public String getAuditor() {
		return auditor;
	}

	public void setAuditor(String auditor) {
		this.auditor = auditor;
	}

	public java.sql.Timestamp getAuditTime() {
		return auditTime;
	}

	public String getAuditTimeString() {
		return date2String(getAuditTime(), FORMAT_CREATE_TIME);
	}

	public void setAuditTimeString(String value) {
		setAuditTime(string2Date(value, FORMAT_CREATE_TIME, java.sql.Timestamp.class));
	}

	public void setAuditTime(java.sql.Timestamp auditTime) {
		this.auditTime = auditTime;
	}

	public String getCreater() {
		return creater;
	}

	public void setCreater(String creater) {
		this.creater = creater;
	}

	public java.sql.Timestamp getCreateTime() {
		return createTime;
	}

	public String getCreateTimeString() {
		return date2String(getCreateTime(), FORMAT_CREATE_TIME);
	}

	public void setCreateTimeString(String value) {
		setCreateTime(string2Date(value, FORMAT_CREATE_TIME, java.sql.Timestamp.class));
	}

	public void setCreateTime(java.sql.Timestamp createTime) {
		this.createTime = createTime;
	}

	public String getUpdater() {
		return updater;
	}

	public void setUpdater(String updater) {
		this.updater = updater;
	}

	public java.sql.Timestamp getUpdateTime() {
		return updateTime;
	}

	public String getUpdateTimeString() {
		return date2String(getUpdateTime(), FORMAT_CREATE_TIME);
	}

	public void setUpdateTimeString(String value) {
		setUpdateTime(string2Date(value, FORMAT_CREATE_TIME, java.sql.Timestamp.class));
	}

	public void setUpdateTime(java.sql.Timestamp updateTime) {
		this.updateTime = updateTime;
	}

	public Integer getLockStatus() {
		return lockStatus;
	}

	public void setLockStatus(Integer lockStatus) {
		this.lockStatus = lockStatus;
	}

	public String getLocker() {
		return locker;
	}

	public void setLocker(String locker) {
		this.locker = locker;
	}

	public java.sql.Timestamp getLockTime() {
		return lockTime;
	}

	public String getLockTimeString() {
		return date2String(getLockTime(), FORMAT_CREATE_TIME);
	}

	public void setLockTimeString(String value) {
		setLockTime(string2Date(value, FORMAT_CREATE_TIME, java.sql.Timestamp.class));
	}

	public void setLockTime(java.sql.Timestamp lockTime) {
		this.lockTime = lockTime;
	}

	public Integer getSort() {
		return sort;
	}

	public void setSort(Integer sort) {
		this.sort = sort;
	}

	public Integer getShowModel() {
		return showModel;
	}

	public void setShowModel(Integer showModel) {
		this.showModel = showModel;
	}

	public String getProcessedItemContent() {
		if (null != itemContent && !itemContent.equals("")) {// 替换填空题和拖拽题中<input>标签为##分隔符
			return itemContent.replaceAll(Constants.MATCH_INPUT_TAG, Constants.SPLIT_TAG_FOR_FTL);
		}
		return itemContent;
	}

	public void setProcessedItemContent(String processedItemContent) {
		this.processedItemContent = processedItemContent;
	}

	public List<ItemAttribute> getAttributeList() {
		return attributeList;
	}

	public void setAttributeList(List<ItemAttribute> attributeList) {
		this.attributeList = attributeList;
	}

	public ItemType getItemType() {
		return itemType;
	}

	public void setItemType(ItemType itemType) {
		this.itemType = itemType;
	}

	public java.sql.Timestamp getAuditTimeBegin() {
		return auditTimeBegin;
	}

	public void setAuditTimeBegin(java.sql.Timestamp auditTimeBegin) {
		this.auditTimeBegin = auditTimeBegin;
	}

	public java.sql.Timestamp getAuditTimeEnd() {
		return auditTimeEnd;
	}

	public void setAuditTimeEnd(java.sql.Timestamp auditTimeEnd) {
		this.auditTimeEnd = auditTimeEnd;
	}

	public java.sql.Timestamp getCreateTimeBegin() {
		return createTimeBegin;
	}

	public void setCreateTimeBegin(java.sql.Timestamp createTimeBegin) {
		this.createTimeBegin = createTimeBegin;
	}

	public java.sql.Timestamp getCreateTimeEnd() {
		return createTimeEnd;
	}

	public void setCreateTimeEnd(java.sql.Timestamp createTimeEnd) {
		this.createTimeEnd = createTimeEnd;
	}

	public java.sql.Timestamp getUpdateTimeBegin() {
		return updateTimeBegin;
	}

	public void setUpdateTimeBegin(java.sql.Timestamp updateTimeBegin) {
		this.updateTimeBegin = updateTimeBegin;
	}

	public java.sql.Timestamp getUpdateTimeEnd() {
		return updateTimeEnd;
	}

	public void setUpdateTimeEnd(java.sql.Timestamp updateTimeEnd) {
		this.updateTimeEnd = updateTimeEnd;
	}

	public java.sql.Timestamp getLockTimeBegin() {
		return lockTimeBegin;
	}

	public void setLockTimeBegin(java.sql.Timestamp lockTimeBegin) {
		this.lockTimeBegin = lockTimeBegin;
	}

	public java.sql.Timestamp getLockTimeEnd() {
		return lockTimeEnd;
	}

	public void setLockTimeEnd(java.sql.Timestamp lockTimeEnd) {
		this.lockTimeEnd = lockTimeEnd;
	}

	public List<Item> getChildItemList() {
		return childItemList;
	}

	public void setChildItemList(List<Item> childItemList) {
		this.childItemList = childItemList;
	}

	public PaperItemRelation getPaperItemRelation() {
		return paperItemRelation;
	}

	public void setPaperItemRelation(PaperItemRelation paperItemRelation) {
		this.paperItemRelation = paperItemRelation;
	}

	public Item getParenItem() {
		return parenItem;
	}

	public void setParenItem(Item parenItem) {
		this.parenItem = parenItem;
	}

	public Integer getDth() {
		return dth;
	}

	public void setDth(Integer dth) {
		this.dth = dth;
	}

	public Integer getXth() {
		return xth;
	}

	public void setXth(Integer xth) {
		this.xth = xth;
	}

	public String getXtdm() {
		return xtdm;
	}

	public void setXtdm(String xtdm) {
		this.xtdm = xtdm;
	}

	public String getFxtdm() {
		return fxtdm;
	}

	public void setFxtdm(String fxtdm) {
		this.fxtdm = fxtdm;
	}

	public String getXtmc() {
		return xtmc;
	}

	public void setXtmc(String xtmc) {
		this.xtmc = xtmc;
	}

	public Integer getZjxh() {
		return zjxh;
	}

	public void setZjxh(Integer zjxh) {
		this.zjxh = zjxh;
	}

	public String getXtlx() {
		return xtlx;
	}

	public void setXtlx(String xtlx) {
		this.xtlx = xtlx;
	}

	public String getItemGroupTitleSection() {
		return itemGroupTitleSection;
	}

	public void setItemGroupTitleSection(String itemGroupTitleSection) {
		this.itemGroupTitleSection = itemGroupTitleSection;
	}

	public String getItemGroupTitleGuide() {
		return itemGroupTitleGuide;
	}

	public void setItemGroupTitleGuide(String itemGroupTitleGuide) {
		this.itemGroupTitleGuide = itemGroupTitleGuide;
	}

	public String getStartGuideAudio() {
		return startGuideAudio;
	}

	public void setStartGuideAudio(String startGuideAudio) {
		this.startGuideAudio = startGuideAudio;
	}

	public String getStartGuideAudioName() {
		return startGuideAudioName;
	}

	public void setStartGuideAudioName(String startGuideAudioName) {
		this.startGuideAudioName = startGuideAudioName;
	}

	public String getEndGuideAudio() {
		return endGuideAudio;
	}

	public void setEndGuideAudio(String endGuideAudio) {
		this.endGuideAudio = endGuideAudio;
	}

	public String getEndGuideAudioName() {
		return endGuideAudioName;
	}

	public void setEndGuideAudioName(String endGuideAudioName) {
		this.endGuideAudioName = endGuideAudioName;
	}

	@Override
	public String toString() {
		
		String attrStr = "";
		if (null != attributeList && !attributeList.isEmpty()) {
			for (ItemAttribute attr : attributeList) {
				attrStr += attr.toString() + ",";
			}
			attrStr = attrStr.substring(0, attrStr.length() - 1);
		}
		return "Item [id=" + id + ", subjectId=" + subjectId + ", itemTypeId=" + itemTypeId + ", score=" + score
				+ ", itemContent=" + itemContent + ", description=" + description + ", keyWord=" + keyWord
				+ ", itemVersion=" + itemVersion + ", difficult=" + difficult + ", parentId=" + parentId + ", itemCode="
				+ itemCode + ", itemLevel=" + itemLevel + ", answerCount=" + answerCount + ", auditor=" + auditor
				+ ", auditStatus=" + auditStatus + ", auditTime=" + auditTime + ", creater=" + creater + ", createTime="
				+ createTime + ", updater=" + updater + ", updateTime=" + updateTime + ", lockStatus=" + lockStatus
				+ ", locker=" + locker + ", lockTime=" + lockTime + ", sort=" + sort + ", showModel=" + showModel
				+ ", processedItemContent=" + processedItemContent + ", attributeList=" + attributeList + ", itemType="
				+ itemType + ", childItemList=" + childItemList + ", paperItemRelation=" + paperItemRelation
				+ ", auditTimeBegin=" + auditTimeBegin + ", auditTimeEnd=" + auditTimeEnd + ", createTimeBegin="
				+ createTimeBegin + ", createTimeEnd=" + createTimeEnd + ", updateTimeBegin=" + updateTimeBegin
				+ ", updateTimeEnd=" + updateTimeEnd + ", lockTimeBegin=" + lockTimeBegin + ", lockTimeEnd="
				+ lockTimeEnd + ", itemTypeName=" + itemTypeName + ", structId=" + structId 
				+ ", dth=" + dth + ", xth=" + xth + ", xtdm=" + xtdm + ", fxtdm=" + fxtdm + ", xtmc=" + xtmc + ", zjxh="
				+ zjxh + ", xtlx=" + xtlx + ", itemGroupTitleSection=" + itemGroupTitleSection
				+ ", itemGroupTitleGuide=" + itemGroupTitleGuide + ", startGuideAudio=" + startGuideAudio
				+ ", startGuideAudioName=" + startGuideAudioName + ", endGuideAudio=" + endGuideAudio
				+ ", endGuideAudioName=" + endGuideAudioName + ", extJson=" + extJson + "]";
	}

//	@Override
//	public String toString() {
//		String attrStr = "";
//		if (null != attributeList && !attributeList.isEmpty()) {
//			for (ItemAttribute attr : attributeList) {
//				attrStr += attr.toString() + ",";
//			}
//			attrStr = attrStr.substring(0, attrStr.length() - 1);
//		}
//
//		return "Item{" + "id=" + id + ", subjectId=" + subjectId + ", itemTypeId=" + itemTypeId + ", score=" + score
//				+ ", itemContent=" + itemContent + ", description=" + description + ", keyWord=" + keyWord
//				+ ", itemVersion=" + itemVersion + ", difficult=" + difficult + ", parentId=" + parentId + ", itemCode="
//				+ itemCode + ", itemLevel=" + itemLevel + ", answerCount=" + answerCount + ", auditor=" + auditor
//				+ ", auditStatus=" + auditStatus + ", auditTime=" + auditTime + ", creater=" + creater + ", createTime="
//				+ createTime + ", sort=" + sort + ", showModel=" + showModel + ", attributeList=[" + attrStr + "]"
//				+ ", itemType=[" + itemType + "]" + ", childItemList=[" + childItemList + "]" + "}";
//	}


    public Integer getIsFinished() {
        return isFinished;
    }

    public void setIsFinished(Integer isFinished) {
        this.isFinished = isFinished;
    }

	public String getSyllabusBasis() {
		return syllabusBasis;
	}

	public void setSyllabusBasis(String syllabusBasis) {
		this.syllabusBasis = syllabusBasis;
	}

	public String getTeachingMaterialBasis() {
		return teachingMaterialBasis;
	}

	public void setTeachingMaterialBasis(String teachingMaterialBasis) {
		this.teachingMaterialBasis = teachingMaterialBasis;
	}

	public String getAbilityLevel() {
		return abilityLevel;
	}

	public void setAbilityLevel(String abilityLevel) {
		this.abilityLevel = abilityLevel;
	}

	public String getActualDifficult() {
		return actualDifficult;
	}

	public void setActualDifficult(String actualDifficult) {
		this.actualDifficult = actualDifficult;
	}

	public String getCheckStatus() {
		return checkStatus;
	}

	public void setCheckStatus(String checkStatus) {
		this.checkStatus = checkStatus;
	}

	public String getDiscrimination() {
		return discrimination;
	}

	public void setDiscrimination(String discrimination) {
		this.discrimination = discrimination;
	}

	public String getUserNumber() {
		return userNumber;
	}

	public void setUserNumber(String userNumber) {
		this.userNumber = userNumber;
	}

	public String getPaperName() {
		return paperName;
	}

	public void setPaperName(String paperName) {
		this.paperName = paperName;
	}

	public String getModule() {
		return module;
	}

	public void setModule(String module) {
		this.module = module;
	}

	public String getKnowledgeId() {
		return knowledgeId;
	}

	public void setKnowledgeId(String knowledgeId) {
		this.knowledgeId = knowledgeId;
	}

	public String getExtNo() {
		return extNo;
	}

	public void setExtNo(String extNo) {
		this.extNo = extNo;
	}

	public String getCognitiveGoal() {
		return cognitiveGoal;
	}

	public void setCognitiveGoal(String cognitiveGoal) {
		this.cognitiveGoal = cognitiveGoal;
	}

	public String getItemSource() {
		return itemSource;
	}

	public void setItemSource(String itemSource) {
		this.itemSource = itemSource;
	}

	public String getPropositionCollege() {
		return propositionCollege;
	}

	public void setPropositionCollege(String propositionCollege) {
		this.propositionCollege = propositionCollege;
	}

	public String getAnalysis() {
		return analysis;
	}

	public void setAnalysis(String analysis) {
		this.analysis = analysis;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public Integer getIsComposite() {
		return isComposite;
	}

	public void setIsComposite(Integer isComposite) {
		this.isComposite = isComposite;
	}

	public PaperStructurePO getPaperStructure() {
		return paperStructure;
	}

	public void setPaperStructure(PaperStructurePO paperStructure) {
		this.paperStructure = paperStructure;
	}

	public String getDelFlag() {
		return delFlag;
	}

	public void setDelFlag(String delFlag) {
		this.delFlag = delFlag;
	}

	public void setKnowledgeStr(String knowledgeStr) {
		this.knowledgeStr = knowledgeStr;
	}

	public String getKnowledgeStr() {

		return knowledgeStr;
	}
}
