package com.talkweb.nets.netsTestLib.core.processor.review;

import com.alibaba.fastjson.JSONObject;
import com.talkweb.common.apps.AppSrvRequest;
import com.talkweb.common.apps.AppSrvResponse;
import com.talkweb.common.apps.BaseProcessor;
import com.talkweb.common.exception.AbsExCode;
import com.talkweb.common.exception.BizException;
import com.talkweb.common.page.PageRequest;
import com.talkweb.nets.netsTestLib.data.model.Knowledge;
import com.talkweb.nets.netsTestLib.data.model.TnetUser;
import com.talkweb.nets.netsTestLib.data.model.basicitem.Item;
import com.talkweb.nets.netsTestLib.data.model.basicitem.ItemModifyHistory;
import com.talkweb.nets.netsTestLib.data.model.project.ActivityEntity;
import com.talkweb.nets.netsTestLib.service.UserService;
import com.talkweb.nets.netsTestLib.service.basicitem.ItemModifyHistoryService;
import com.talkweb.nets.netsTestLib.service.basicitem.ItemService;
import com.talkweb.nets.netsTestLib.service.cache.CacheService;
import com.talkweb.nets.netsTestLib.service.project.ActivityService;

import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * 试题修改记录
 * 
 * @author max
 * 
 * @param bizCode:00010033
 */
public class ItemModifyHistoryProcessor implements BaseProcessor {
    @Autowired
    private ItemModifyHistoryService itemModifyHistoryService;
    @Autowired
    private UserService userService;
    @Autowired
    private ItemService itemService;
    @Autowired
    private ActivityService activityService;
    @Autowired
    private CacheService cacheService;

    @SuppressWarnings("unchecked")
    public AppSrvResponse execute(AppSrvRequest req) throws BizException {
        Map<String, Object> map = req.getParamObj();
        PageRequest<Map> pageRequest = new PageRequest();
        AppSrvResponse rep = new AppSrvResponse();

        int pageNum = req.getPage();
        if (pageNum <= 0) {
            pageNum = 1;
        }
        pageRequest.setPageSize(req.getPageSize());
        pageRequest.setPageNumber(pageNum);

        List<String> itemList = new ArrayList<String>();
        String itemId = (String) req.getParamObj().get("itemId");
        List<Item> childItems = itemService.getChildItemsByItemId(itemId); // 查询复合题下面的子题
        // 父题更新记录在上，子题更新记录在下
        itemList.add(itemId);
        if (!childItems.isEmpty() && childItems.size() > 0) {
            for (Item item : childItems) {
                itemList.add(item.getId());
            }
        }

        List<Map<String, Object>> result = new ArrayList<>();
        for (int i = 0; i < itemList.size(); i++) {
            List<List<Object>> list = itemModifyHistoryService.getAllVersionsByItemId(itemList.get(i));
            for (int j = 0; j < list.size(); j++) {
                if (j != (list.size() - 1)) {
                    Map<String, Object> combination = new TreeMap<String, Object>();
                    combination.put("old", list.get(j));
                    combination.put("new", list.get(j + 1));
                    Map<String, Object> re = compareVersion(combination);
                    if (re.size() > 0) {
                        result.add(re);
                    }
                }
            }
        }

        rep.setTotalCount(result.size());
        rep.setCode(AbsExCode.SUCCESS.getErrorCode());
        rep.setErrMsg(AbsExCode.SUCCESS.getErrorMsg());
        rep.setBizCode(req.getBizCode());
        rep.setRet(result);
        rep.setPageSize(req.getPageSize());
        rep.setPageNumber(req.getPage());
        rep.setReqSsn(req.getReqSsn());
        return rep;
    }

    /**
     * 比较版本 返回结果
     * 
     * @param versions
     * @return
     */
    @SuppressWarnings("unchecked")
    public Map<String, Object> compareVersion(Map<String, Object> versions) {
        Map<String, Object> resultMap = new HashMap<String, Object>();
        ItemModifyHistory itemModifyHistoryOld = (ItemModifyHistory) versions.get("old");
        ItemModifyHistory itemModifyHistoryNew = (ItemModifyHistory) versions.get("new");

        // 处理知识点和不需要比较的字段
        String jsonOld = getKnowledgeString(JsonUtils.dealJSON(itemModifyHistoryOld.getItemJson()));
        String jsonNew = getKnowledgeString(JsonUtils.dealJSON(itemModifyHistoryNew.getItemJson()));

        String operater = itemModifyHistoryNew.getOperater();
        String activityId = itemModifyHistoryNew.getActivityId();

        TnetUser tnetUser = (TnetUser) userService.get(operater);
        ActivityEntity activityEntity = (ActivityEntity) activityService.get(activityId);

        List<Map<String, String>> operaterField = JsonUtils.compareJSON(jsonOld, jsonNew); // 开始比较不同之处
        if (operaterField.size() > 0) {
            resultMap.put("operaterName", tnetUser.getUserName());
            resultMap.put("activityId", activityEntity.getId());
            resultMap.put("activityName", activityEntity.getName());
            resultMap.put("itemId", itemModifyHistoryNew.getItemId());
            resultMap.put("activityDescription", activityEntity.getDescription());
            resultMap.put("operaterField", operaterField);
            resultMap.put("operateTime", itemModifyHistoryNew.getOperateTimeString());
        }
        return resultMap;
    }

    /**
     * 把知识点id转换为知识点文字目录
     * 
     * @Title: getKnowledgeString
     * @Description: 把知识点id转换为知识点文字目录
     * @Param o
     * @return String
     */
    private String getKnowledgeString(String o) {

        JSONObject json = JSONObject.parseObject(o);
        if(json.get("knowledgeId") == null) return o;
        String knowledgeId = json.get("knowledgeId").toString();

        Knowledge knowledge = cacheService.getKnowledgeById(knowledgeId);
        if (knowledge == null) {
            json.put("knowledgeId", "");
        } else {
            String knowledgeStr = knowledge.getLine();
            String[] knowledgeArr = knowledgeStr.split("_");
            StringBuffer ItemKnowledgeStr = new StringBuffer();
            if (knowledgeArr.length >= 4) {

                ItemKnowledgeStr.append(cacheService.getKnowledgeById(knowledgeArr[0]).getName() + "/");
                ItemKnowledgeStr.append(cacheService.getKnowledgeById(knowledgeArr[1]).getName() + "/");
                ItemKnowledgeStr.append(cacheService.getKnowledgeById(knowledgeArr[2]).getName() + "/");
                ItemKnowledgeStr.append(cacheService.getKnowledgeById(knowledgeArr[3]).getName());

                json.put("knowledgeId", ItemKnowledgeStr.toString());
            } else if (knowledgeArr.length == 3) {

                ItemKnowledgeStr.append(cacheService.getKnowledgeById(knowledgeArr[0]).getName() + "/");
                ItemKnowledgeStr.append(cacheService.getKnowledgeById(knowledgeArr[1]).getName() + "/");
                ItemKnowledgeStr.append(cacheService.getKnowledgeById(knowledgeArr[2]).getName());
                json.put("knowledgeId", ItemKnowledgeStr.toString());
            } else if (knowledgeArr.length == 2) {

                ItemKnowledgeStr.append(cacheService.getKnowledgeById(knowledgeArr[0]).getName() + "/");
                ItemKnowledgeStr.append(cacheService.getKnowledgeById(knowledgeArr[1]).getName());
                json.put("knowledgeId", ItemKnowledgeStr.toString());
            } else if (knowledgeArr.length == 1) {

                ItemKnowledgeStr.append(cacheService.getKnowledgeById(knowledgeArr[0]).getName());
                json.put("knowledgeId", ItemKnowledgeStr.toString());
            }
        }
        return json.toString();
    }
}