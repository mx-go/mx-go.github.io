package com.talkweb.nets.netsTestLib.core.processor.review;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import com.google.common.collect.MapDifference;
import com.google.common.collect.Maps;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * 试题版本对比
 * 创建人：maxu 
 * 创建时间：2017年9月19日 上午9:35:34
 * @Description: 试题版本对比
 */
public class JsonUtils {
    /**
     * 处理json字符串
     * 
     * @param jsonString
     * @param tr
     * @return
     */
    @SuppressWarnings("unchecked")
    public static <T> T readJsonToObject(String jsonString, TypeReference<T> tr) {
        ObjectMapper objectMapper = new ObjectMapper();
        if (jsonString == null || "".equals(jsonString)) {
            return null;
        } else {
            try {
                return (T) objectMapper.readValue(jsonString, tr);
            } catch (Exception e) {

                e.printStackTrace();
            }
        }
        return null;
    }

    /**
     * 比较版本json主方法
     * 
     * @param oldVersion：旧版本
     * @param newVersion：新版本
     * @return
     */
    @SuppressWarnings({ "unchecked", "rawtypes" })
    public static List<Map<String, String>> compareMap(Map<String, Object> oldVersion, Map<String, Object> newVersion) {

        MapDifference<String, Object> difference = Maps.difference(oldVersion, newVersion);

        // 获取所有不同点
        Map<String, MapDifference.ValueDifference<Object>> differenceMap = difference.entriesDiffering();
        List<Map<String, String>> result = new ArrayList<>();
        Iterator diffIterator = differenceMap.entrySet().iterator();
        while (diffIterator.hasNext()) {
            Map.Entry entry = (java.util.Map.Entry) diffIterator.next();

            MapDifference.ValueDifference<Object> valueDifference = (MapDifference.ValueDifference<Object>) entry
                    .getValue();
            boolean isList = valueDifference.leftValue() instanceof List
                    && valueDifference.rightValue() instanceof List;
            boolean isMap = valueDifference.leftValue() instanceof Map && valueDifference.rightValue() instanceof Map;
            if (!isList && !isMap) {
                Map<String, String> map = new HashMap<>();
                String fieldKey = String.valueOf(entry.getKey());

                // 选择题中选项内容改变
                if (oldVersion.get("content") != null && oldVersion.get("name") != null) {
                    map.put("fieldName", judgeOption(oldVersion.get("name").toString()));
                } else {
                    map.put("fieldName", judgeFiledName(fieldKey));
                }
                map.put("fieldKey", fieldKey);
                map.put("oldValue", judgeFiledKey(fieldKey, valueDifference.leftValue().toString()));
                map.put("newValue", judgeFiledKey(fieldKey, valueDifference.rightValue().toString()));
                result.add(map);
            }

            // 处理结果是否为List,则递归执行比较规则
            if (valueDifference.leftValue() instanceof List && valueDifference.rightValue() instanceof List) {
                JSONArray j = JSONArray.parseArray(JSON.toJSONString(valueDifference.leftValue()));
                JSONArray p = JSONArray.parseArray(JSON.toJSONString(valueDifference.rightValue()));
                JSONObject js = new JSONObject();
                JSONObject js1 = new JSONObject();
                for (int i = 0; i < j.size(); i++) {
                    js.put(i + "", j.get(i));
                }
                for (int i = 0; i < p.size(); i++) {
                    js1.put(i + "", p.get(i));
                }
                Map<String, Object> requestMap = JsonUtils.readJsonToObject(js.toString(),
                        new TypeReference<Map<String, Object>>() {
                        });
                Map<String, Object> requestMap1 = JsonUtils.readJsonToObject(js1.toString(),
                        new TypeReference<Map<String, Object>>() {
                        });
                result.add(compareMap(requestMap, requestMap1).get(0));
            }
            // 处理结果是否为Map,则递归执行比较规则
            if (valueDifference.leftValue() instanceof Map && valueDifference.rightValue() instanceof Map) {
                result.add(compareMap((Map<String, Object>) valueDifference.leftValue(),
                        (Map<String, Object>) valueDifference.rightValue()).get(0));
            }
        }

        // 若A中有B中不存在的值
        Map<String, Object> entriesOnlyOnLeft = difference.entriesOnlyOnLeft();
        if (entriesOnlyOnLeft != null && !entriesOnlyOnLeft.isEmpty()) {

            Iterator it = entriesOnlyOnLeft.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<String, String> entry = (java.util.Map.Entry) it.next();
                Map<String, String> map = new HashMap<>();
                String fieldKey = entry.getKey();
                map.put("fieldKey", fieldKey);
                map.put("fieldName", judgeFiledName(fieldKey));
                map.put("oldValue", judgeFiledKey(fieldKey, String.valueOf(entry.getValue())));
                map.put("newValue", "");
                result.add(map);
            }
        }

        // 若B中有A中不存在的值
        Map<String, Object> onlyOnRightMap = difference.entriesOnlyOnRight();
        if (onlyOnRightMap != null && !onlyOnRightMap.isEmpty()) {
            Iterator it = onlyOnRightMap.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<String, String> entry = (java.util.Map.Entry) it.next();
                Map<String, String> map = new HashMap<>();
                String fieldKey = String.valueOf(entry.getKey());
                map.put("fieldKey", fieldKey);
                map.put("fieldName", judgeFiledName(fieldKey));
                map.put("oldValue", "");
                map.put("newValue", judgeFiledKey(fieldKey, String.valueOf(entry.getValue())));
                result.add(map);
            }
        }
        return result;
    }

    public static List<Map<String, String>> compareJSON(String jsonOld, String jsonNew) {
        Map<String, Object> oldVersion = JsonUtils.readJsonToObject(jsonOld, new TypeReference<Map<String, Object>>() {
        });
        Map<String, Object> newVersion = JsonUtils.readJsonToObject(jsonNew, new TypeReference<Map<String, Object>>() {
        });
        return compareMap(oldVersion, newVersion);
    }

    public static void main(String[] args) {
        // old version
        String jsonData = "{\"abilityLevel\":\"1\",\"analysis\":\"\",\"answer\":\"A\",\"attributeList\":[{\"content\":\"<p style=\\\"font-family:&#39;Times New Roman&#39;,SimSun;font-size:10.5pt;\\\">2</p>\",\"id\":\"20170918185753000083\",\"itemId\":\"20170915101755000012\",\"name\":\"A\",\"sort\":1,\"type\":\"option\"},{\"content\":\"<p style=\\\"font-family:&#39;Times New Roman&#39;,SimSun;font-size:10.5pt;\\\">3</p>\",\"id\":\"20170918185753000084\",\"itemId\":\"20170915101755000012\",\"name\":\"B\",\"sort\":2,\"type\":\"option\"},{\"content\":\"<p style=\\\"font-family:&#39;Times New Roman&#39;,SimSun;font-size:10.5pt;\\\">1</p>\",\"id\":\"20170918185753000085\",\"itemId\":\"20170915101755000012\",\"name\":\"C\",\"sort\":3,\"type\":\"option\"},{\"content\":\"<p style=\\\"font-family:&#39;Times New Roman&#39;,SimSun;font-size:10.5pt;\\\">3</p>\",\"id\":\"20170918185753000086\",\"itemId\":\"20170915101755000012\",\"name\":\"D\",\"sort\":4,\"type\":\"option\"}],\"childItemList\":[],\"difficult\":\"4\",\"id\":\"20170915101755000012\",\"isComposite\":0,\"isFinished\":1,\"itemCode\":\"KJCJ000000012\",\"itemContent\":\"<p style=\\\"font-family:&#39;Times New Roman&#39;,SimSun;font-size:10.5pt;\\\">12311</p>\",\"itemLevel\":0,\"itemTypeId\":\"1\",\"itemVersion\":\"6\",\"keyWord\":\"11\",\"knowledgeId\":\"40055\",\"lockStatus\":1,\"paperItemRelation\":{},\"paperStructure\":{},\"parentId\":\"-1\",\"processedItemContent\":\"<p style=\\\"font-family:&#39;Times New Roman&#39;,SimSun;font-size:10.5pt;\\\">12311</p>\",\"score\":12,\"subjectId\":\"4\",\"syllabusBasis\":\"11\",\"teachingMaterialBasis\":\"11\",\"updateTime\":1505732272970,\"updateTimeString\":\"2017-09-18 18:57:52\",\"updater\":\"10001\"}";
        // new version
        String jsonData1 = "{\"abilityLevel\":\"1\",\"analysis\":\"1\",\"answer\":\"AB\",\"attributeList\":[{\"content\":\"<p style=\\\"font-family:&#39;Times New Roman&#39;,SimSun;font-size:10.5pt;\\\">21</p>\",\"id\":\"20170918185753000083\",\"itemId\":\"20170915101755000012\",\"name\":\"A\",\"sort\":1,\"type\":\"option\"},{\"content\":\"<p style=\\\"font-family:&#39;Times New Roman&#39;,SimSun;font-size:10.5pt;\\\">3</p>\",\"id\":\"20170918185753000084\",\"itemId\":\"20170915101755000012\",\"name\":\"B\",\"sort\":2,\"type\":\"option\"},{\"content\":\"<p style=\\\"font-family:&#39;Times New Roman&#39;,SimSun;font-size:10.5pt;\\\">1</p>\",\"id\":\"20170918185753000085\",\"itemId\":\"20170915101755000012\",\"name\":\"C\",\"sort\":3,\"type\":\"option\"},{\"content\":\"<p style=\\\"font-family:&#39;Times New Roman&#39;,SimSun;font-size:10.5pt;\\\">3</p>\",\"id\":\"20170918185753000086\",\"itemId\":\"20170915101755000012\",\"name\":\"D\",\"sort\":4,\"type\":\"option\"}],\"childItemList\":[],\"difficult\":\"4\",\"id\":\"20170915101755000012\",\"isComposite\":0,\"isFinished\":1,\"itemCode\":\"KJCJ000000012\",\"itemContent\":\"<p style=\\\"font-family:&#39;Times New Roman&#39;,SimSun;font-size:10.5pt;\\\">12311</p>\",\"itemLevel\":0,\"itemTypeId\":\"1\",\"itemVersion\":\"6\",\"keyWord\":\"11\",\"knowledgeId\":\"40055\",\"lockStatus\":1,\"paperItemRelation\":{},\"paperStructure\":{},\"parentId\":\"-1\",\"processedItemContent\":\"<p style=\\\"font-family:&#39;Times New Roman&#39;,SimSun;font-size:10.5pt;\\\">12311</p>\",\"score\":12,\"subjectId\":\"4\",\"syllabusBasis\":\"11\",\"teachingMaterialBasis\":\"11\",\"updateTime\":1505732272970,\"updateTimeString\":\"2017-09-18 18:57:52\",\"updater\":\"10001\"}";
        System.out.println("result =====  \n" + compareJSON(jsonData, jsonData1));
    }

    /**
     * 选择题判断选项
     * 
     * @param option：选项
     * @return
     */
    public static String judgeOption(String option) {
        String fieldName = "选项" + option + "内容";
        return fieldName;
    }

    /**
     * 判断字段名称
     * 
     * @param filedKey
     * @return
     */
    public static String judgeFiledName(String fieldKey) {
        String fieldName = "";

        if (!StringUtils.isEmpty(fieldKey)) {
            switch (fieldKey) {
            case "abilityLevel":
                fieldName = "能力层次";
                break;
            case "analysis":
                fieldName = "答案解析";
                break;
            case "answer":
                fieldName = "答案";
                break;
            case "content":
                fieldName = "内容";
                break;
            case "difficult":
                fieldName = "难度系数";
                break;
            case "itemContent":
                fieldName = "题干内容";
                break;
            case "itemLevel":
                fieldName = "试题级别";
                break;
            case "itemTypeId":
                fieldName = "题型";
                break;
            case "keyWord":
                fieldName = "关键字";
                break;
            case "knowledgeId":
                fieldName = "知识点";
                break;
            case "processedItemContent":
                fieldName = "题干内容";
                break;
            case "score":
                fieldName = "分数";
                break;
            case "subjectId":
                fieldName = "科目编号";
                break;
            case "syllabusBasis":
                fieldName = "大纲依据";
                break;
            case "description":
                fieldName = "说明";
                break;
            case "auditor":
                fieldName = "审核人";
                break;
            case "auditStatus":
                fieldName = "审核状态";
                break;
            case "extJson":
                fieldName = "附加属性";
                break;
            case "checkStatus":
                fieldName = "校核状态";
                break;
            case "itemType":
                fieldName = "题型信息";
                break;
            case "teachingMaterialBasis":
                fieldName = "教材依据";
                break;
            case "propositionCollege":
                fieldName = "命题院校";
                break;
            default:
                fieldName = "内容";
                break;
            }
        }
        return fieldName;
    }

    /**
     * 判断字段别称
     * 
     * @param filedKey
     *            nickValue
     * @return
     */
    public static String judgeFiledKey(String fieldKey, String nickValue) {
        String value = "";

        if (!StringUtils.isEmpty(fieldKey)) {
            switch (fieldKey) {
            case "answer":
                switch (nickValue) {
                case "wrong":
                    value = "错误";
                    break;
                case "right":
                    value = "正确";
                    break;
                default:
                    value = nickValue;
                    break;
                }
                break;
            case "abilityLevel":
                switch (nickValue) {
                case "1":
                    value = "掌握";
                    break;
                case "2":
                    value = "熟悉";
                    break;
                case "3":
                    value = "了解";
                    break;
                default:
                    value = nickValue;
                    break;
                }
                break;
            case "difficult":
                value = (Integer.parseInt(nickValue) / 10.0) + "";
                break;
            case "auditStatus":
                switch (nickValue) {
                case "0":
                    value = "待审核";
                    break;
                case "1":
                    value = "审核退回";
                    break;
                case "2":
                    value = "审核待修改";
                    break;
                case "3":
                    value = "审核通过";
                    break;
                default:
                    value = nickValue;
                    break;
                }
                break;
            case "checkStatus":
                switch (nickValue) {
                case "1":
                    value = "通过";
                    break;
                case "2":
                    value = "未通过";
                    break;
                default:
                    value = nickValue;
                    break;
                }
                break;
            default:
                value = nickValue;
                break;
            }
        }
        return value;
    }

    /**
     * 将不需要对比的字段去掉
     * 
     * @param json
     * @return
     */
    public static String dealJSON(String json) {
        JSONObject jsonObject = JSONObject.parseObject(json);
        jsonObject.remove("lockStatus");
        jsonObject.remove("updateTime");
        jsonObject.remove("createTime");
        jsonObject.remove("delFlag");
        jsonObject.remove("createTimeString");
        jsonObject.remove("updateTimeString");
        jsonObject.remove("updater");
        jsonObject.remove("creater");
        jsonObject.remove("locker");
        jsonObject.remove("lockStatus");
        jsonObject.remove("lockTime");
        jsonObject.remove("isFinished");
        jsonObject.remove("parentId");
        jsonObject.remove("itemVersion");
        jsonObject.remove("processedItemContent");
        jsonObject.remove("itemType");
        jsonObject.remove("activityId");
        JSONArray attributeList = (JSONArray) jsonObject.get("attributeList");
        Iterator<Object> it = attributeList.iterator();
        while (it.hasNext()) {
            JSONObject object = (JSONObject) it.next();
            object.remove("id");
        }
        return jsonObject.toString();
    }
}
